from flask import Flask, render_template
import random
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/dado')
def dado():
    return render_template("dado.html",
                          numero = random.randint(1,6))

@app.route('/fecha')
def fecha():
    inicio = datetime(1970, 1, 1)
    final =  datetime(2100, 12, 1)
    return render_template("fecha.html",
                          random_date = inicio + (final - inicio) * random.random())

@app.route('/color')
def color():
    return render_template("color.html", 
                           color = ["#"+''.join([random.choice('0123456789ABCDEF') for j in range(6)])])
app.run(host='0.0.0.0', port=81)