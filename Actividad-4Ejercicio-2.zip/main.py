from flask import Flask, render_template
import sqlite3


app = Flask(__name__)

@app.route('/')
def index():
    return render_template("home.html")




@app.route('/listado')
def listado():
  lista = []
  top10 = []
  conn = sqlite3.connect('co_emissions.db')
  q = f"""SELECT Value, Country FROM emissions WHERE Series = '{"pcap"}' and Year = '{2018}'"""
  resu = conn.execute(q)
  for a in range(10):
      for n in resu:
          lista.append((float(n[0]), n[1]))
      idx, max_value = max(lista, key=lambda item: item[0])
      lista.remove((idx, max_value))
      top10.append(max_value)
  conn.close()
  
  return render_template("listado.html",
                         listar = top10)




@app.route('/listado/top')
def listadoTop():
  lista = []
  top10 = []
  conn = sqlite3.connect('co_emissions.db')
  q = f"""SELECT Value, Country FROM emissions WHERE Series = '{"total"}' and Year = '{2018}'"""
  resu = conn.execute(q)
  for a in range(10):
      for n in resu:
          lista.append((float(n[0]), n[1]))
      idx, max_value = max(lista, key=lambda item: item[0])
      lista.remove((idx, max_value))
      top10.append(max_value)
  conn.close()
  return render_template("listadoTop.html",
                          listad = top10)





@app.route('/listado/argentina')
def listadoArgentina():
  lista1 = []
  lista2 = []
  conn = sqlite3.connect('co_emissions.db')
  q = f"""SELECT Country, Value FROM emissions WHERE Series = '{"total"}' and Year = '{2018}'"""
  resu = conn.execute(q)
  w = f"""SELECT Value FROM emissions WHERE Series = '{"pcap"}' and Year = '{2018}'"""
  resul = conn.execute(w)
  for n in resu:
      lista1.append(n)
  for m in resul:
      lista2.append(m)
  conn.close()
  
  return render_template("listadoArgentina.html",
                          l1 = lista1,
                          l2 = lista2,
                          longitud = len(lista1))

@app.route('/ayuda')
def ayuda():
    return render_template("ayuda.html")



  
app.run(host='0.0.0.0', port=81)